# Telosys 3 Basic template sample

A Set of basic templates usable with code generator Telosys Tools 3.  
The generated files gives you multiple samples to tinker with, to understand how generation works and how you can generate your entities in any proposed language. 

## Installation

1. Download the template.
2. Provide your DSL/Database model.
3. Generate the code with Telosys.  

## Getting started

- Import the generated files in your project.

## More info

[About Telosys Tools](http://www.telosys.org/) | [Telosys CLI](http://telosys.org/cli.html)
