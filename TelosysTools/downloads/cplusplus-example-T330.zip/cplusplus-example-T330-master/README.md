# Telosys bundle of templates for basic C++ classes

This bundle is available for demonstration and learning purposes to get started with Telosys

It generates very basic C++ classes 

A C++ class is generated for each entity

NB : requires Telosys version >= 3.3.0
