# python-persistence-sqlalchemy

Telosys templates for **Python database persistence** based on **SqlAlchemy** framework

## Dependencies : 

None
