# python-web-rest-bottle

Telosys templates for Python REST web application based on Bottle framework

## Dependencies : 

This bundle requires the following bundles :
- **python-persistence-sqlalchemy** : https://github.com/telosys-templates-v3/python-persistence-sqlalchemy
