
public class MyData {
	
	// Set my data values here 
	private final int    id   = 0 ;
	private final String name = "Foo" ;
	
	public MyData() {
		
	}
	
	public int getId() {
		return id ;
	}

	public String getName() {
		return name ;
	}
	
}