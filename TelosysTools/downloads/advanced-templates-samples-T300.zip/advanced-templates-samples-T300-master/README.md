Set of advanced templates using ...

- $loader to use specific Java classes in the templates 
  NB : Java classes must be compiled with "build.xml" ant file before launching the generation

- $generator to launch the generator from a template file
