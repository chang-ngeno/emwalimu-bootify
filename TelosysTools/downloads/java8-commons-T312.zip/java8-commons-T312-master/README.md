# Telosys templates bundle for Java application commons

A [Telosys](http://www.telosys.org) bundle to generate common components :
- records
- persistence interfaces
- fake persistence implementation
- list-items 
- basic JUnit tests

## Bundle for Telosys ver 3.1.2

## Requirements

- Java 8

## Dependencies

None


## License

This project uses the [LGPL v3 License](https://www.gnu.org/licenses/lgpl-3.0.en.html).
