# Node.JS Telosys 3 Template

This is a Telosys Template for code generation.
It's purpose is to generate a NodeJS REST API after having provided a DSL model.

The generated server Application is a NodeJS REST API using SQLite as database. The application is written in JavaScript ES6.

Check installation guide [here](https://github.com/telosys-templates-v3/javascript-web-rest-nodejs-express/wiki).