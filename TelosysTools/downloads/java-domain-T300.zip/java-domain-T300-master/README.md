# Telosys bundle of templates for basic Java domain classes

This bundle is available for demonstration and learning purposes to get started with Telosys

It generates very basic Java domain classes (pure Java without dependencies)

A domain class is generated for each entity with a basic JUnit test case 

