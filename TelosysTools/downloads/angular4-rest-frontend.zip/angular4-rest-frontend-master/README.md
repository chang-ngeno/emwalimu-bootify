# Angular 4 front end (for Telosys 3)

This is a Telosys templates bundle designed to generated an Angular 4 rest frontend (written in TypeScript).

Check installation guide [here](https://github.com/telosys-templates-v3/typesscript-angular4-rest-frontend/wiki).
