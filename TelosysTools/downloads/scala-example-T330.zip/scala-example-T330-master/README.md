# Telosys bundle of templates for basic SCALA classes

This bundle is available for demonstration and learning purposes to get started with Telosys

It generates very basic Scala classes 

A Scala class is generated for each entity

NB : requires Telosys version >= 3.3.0
