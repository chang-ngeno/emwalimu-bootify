# python-web-mvc-bottle

Telosys templates for Python MVC web application based on Bottle framework

## Dependencies : 

This bundle requires the following bundles :
- **python-persistence-sqlalchemy** : https://github.com/telosys-templates-v3/python-persistence-sqlalchemy

